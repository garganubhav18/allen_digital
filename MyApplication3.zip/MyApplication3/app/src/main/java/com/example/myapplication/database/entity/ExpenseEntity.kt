package com.example.myapplication.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expense_entity")
data class ExpenseEntity(
    @PrimaryKey
    @ColumnInfo(name = "expenseId")
    val expenseId: String,
    val expenseName: String,
    val groupId: String
)