package com.example.myapplication.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_member_info")
data class GroupMembersInfo(

    @PrimaryKey
    val memberId: String,
    val groupId: String,
    val memberName: String
)