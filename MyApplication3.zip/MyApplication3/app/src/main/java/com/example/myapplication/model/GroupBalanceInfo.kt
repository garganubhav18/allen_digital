package com.example.myapplication.model

data class GroupBalanceInfo(
    val fromMemberId: String,
    val toMemberId: String,
    val balanceInPaise: Long
)