package com.example.myapplication.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE

@Entity(
    tableName = "expense_member_entity", foreignKeys = [ForeignKey(
        entity = ExpenseEntity::class,
        parentColumns = arrayOf("expenseId"),
        childColumns = arrayOf("memberExpenseId"),
        onDelete = CASCADE
    )]
)
class ExpenseMemberEntity(

    val memberExpenseId: String,
    val groupId: String,
    val fromMemberId: String,
    val toMemberId: String,
    val balanceInPaise: Long
)