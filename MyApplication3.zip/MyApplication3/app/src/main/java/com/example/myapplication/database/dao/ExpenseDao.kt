package com.example.myapplication.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.myapplication.database.entity.ExpenseEntity
import com.example.myapplication.database.entity.ExpenseMemberEntity
import com.example.myapplication.database.entity.GroupMembersInfo
import com.example.myapplication.model.ExpenseMemberInfo
import com.example.myapplication.model.GroupBalanceInfo

@Dao
abstract class ExpenseDao {

    @Query("Select * From group_member_info Where groupId = :groupId")
    abstract suspend fun getMemberInfoByGroupId(groupId: String): List<GroupMembersInfo>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertExpenseEntity(expenseEntity: ExpenseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertMemberEntity(expenseMemberEntity: List<ExpenseMemberEntity>)

    @Query("Select * From expense_entity left join expense_member_entity On expense_entity.expenseId = expense_member_entity.memberExpenseId where expense_entity.expenseId = :expenseId")
    abstract suspend fun getExpenseMember(expenseId: String): ExpenseMemberInfo

    @Query("Select expense_member_entity.fromMemberId, expense_member_entity.toMemberId, sum(expense_member_entity.balanceInPaise) from expense_member_entity where expense_member_entity.groupId = :groupId group by expense_member_entity.fromMemberId")
    abstract suspend fun getMemberBalanceByGroupId(groupId: String): List<GroupBalanceInfo>?

    @Query("Select expense_member_entity.fromMemberId, expense_member_entity.toMemberId, expense_member_entity.balanceInPaise from expense_member_entity where expense_member_entity.fromMemberId = :memberId OR expense_member_entity.toMemberId = :memberId")
    abstract suspend fun getMemberBalancesByMemberId(memberId: String): List<GroupBalanceInfo>
}