package com.example.myapplication.model

data class SplitExpenseParams(
    val groupId: String
)