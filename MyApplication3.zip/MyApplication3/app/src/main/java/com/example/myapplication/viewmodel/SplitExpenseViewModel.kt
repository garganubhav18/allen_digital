package com.example.myapplication.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.database.dao.ExpenseDao
import com.example.myapplication.database.entity.ExpenseEntity
import com.example.myapplication.database.entity.ExpenseMemberEntity
import com.example.myapplication.database.entity.GroupMembersInfo
import com.example.myapplication.model.GroupBalanceInfo
import com.example.myapplication.model.SplitExpenseParams
import kotlinx.coroutines.launch

class SplitExpenseViewModel(private val expenseDao: ExpenseDao): ViewModel() {

    private val _showMembers = MutableLiveData<List<GroupMembersInfo>>()
    private val _showGroupMembersBalance = MutableLiveData<List<GroupBalanceInfo>>()
    private val _showMemberBalanceDetail = MutableLiveData<List<GroupBalanceInfo>>()
    val showMembers: LiveData<List<GroupMembersInfo>> = _showMembers
    val showGroupMembersBalance: LiveData<List<GroupBalanceInfo>> = _showGroupMembersBalance
    val showMemberBalanceDetail: LiveData<List<GroupBalanceInfo>> = _showMemberBalanceDetail

    private lateinit var members: List<GroupMembersInfo>
    private lateinit var groupId: String

    fun onCreate(params: SplitExpenseParams) {
        this.groupId = params.groupId
        fetchMembers(params.groupId)
    }

    private fun fetchMembers(groupId: String) {
        viewModelScope.launch {
            members = expenseDao.getMemberInfoByGroupId(groupId)
            _showMembers.value = members
        }
    }

    fun addExpense(totalAmountInPaise: Long, expenseName: String, payer: GroupMembersInfo) {
        val payeeSize = members.size - 1
        val payeeMembers = members.filter { it.memberId != payer.memberId }
        val eachPayerAmount = totalAmountInPaise/(payeeSize)
        var offsetRemaining = totalAmountInPaise % payeeSize
        val expenseMemberEntity = payeeMembers.map {
            val balance = if(offsetRemaining == 0L) {
                eachPayerAmount
            } else {
                offsetRemaining--
                eachPayerAmount + 1
            }
            ExpenseMemberEntity(
                "expenseId",
                groupId,
                payer.memberId,
                it.memberId,
                balance
            )
        }
        val expenseEntity = ExpenseEntity(
            "expenseId",
            expenseName,
            groupId
        )

        viewModelScope.launch {
            expenseDao.insertExpenseEntity(expenseEntity)
            expenseDao.insertMemberEntity(expenseMemberEntity)
        }
    }

    fun fetchAndShowGroupMembersBalance() {
        viewModelScope.launch {
            val groupBalanceInfo = expenseDao.getMemberBalanceByGroupId(groupId)
            _showGroupMembersBalance.value = groupBalanceInfo
        }
    }

    fun onMemberClicked(member: GroupMembersInfo) {
        viewModelScope.launch {
            val memberBalanceInfo = expenseDao.getMemberBalancesByMemberId(member.memberId)
            _showMemberBalanceDetail.value = memberBalanceInfo
        }
    }

}