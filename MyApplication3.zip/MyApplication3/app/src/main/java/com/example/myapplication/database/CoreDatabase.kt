package com.example.myapplication.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.myapplication.database.dao.ExpenseDao
import com.example.myapplication.database.entity.GroupMembersInfo

@Database(entities = [GroupMembersInfo::class], version = 1)
abstract class CoreDatabase: RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
}