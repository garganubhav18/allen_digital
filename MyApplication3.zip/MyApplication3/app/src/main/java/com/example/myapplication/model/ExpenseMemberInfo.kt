package com.example.myapplication.model

import com.example.myapplication.database.entity.ExpenseEntity
import com.example.myapplication.database.entity.ExpenseMemberEntity


data class ExpenseMemberInfo(
    val expenseEntity: ExpenseEntity,
    val memberEntities: List<ExpenseMemberEntity>
)